@extends('tenant.layouts.admin')

@section('title', 'Dashboard')
@section('page-title', 'Dashboard')

@section('content')
<div class="page-header">
    <h1 class="page-title">Welcome to Your Dashboard!</h1>
    <p class="page-subtitle">You are successfully logged in to your tenant account.</p>
</div>

<div class="card">
    <h3 style="margin-top: 0; color: #333;">Your Profile Information</h3>
    
    <div style="display: flex; margin-bottom: 10px;">
        <span style="font-weight: 500; color: #333; width: 120px;">Name:</span>
        <span style="color: #666;">{{ $user->name }}</span>
    </div>
    
    <div style="display: flex; margin-bottom: 10px;">
        <span style="font-weight: 500; color: #333; width: 120px;">Email:</span>
        <span style="color: #666;">{{ $user->email }}</span>
    </div>
    
    @if($user->phone)
    <div style="display: flex; margin-bottom: 10px;">
        <span style="font-weight: 500; color: #333; width: 120px;">Phone:</span>
        <span style="color: #666;">{{ $user->phone }}</span>
    </div>
    @endif
    
    @if($user->company)
    <div style="display: flex; margin-bottom: 10px;">
        <span style="font-weight: 500; color: #333; width: 120px;">Company:</span>
        <span style="color: #666;">{{ $user->company }}</span>
    </div>
    @endif
    
    @if($user->address)
    <div style="display: flex; margin-bottom: 10px;">
        <span style="font-weight: 500; color: #333; width: 120px;">Address:</span>
        <span style="color: #666;">{{ $user->address }}</span>
    </div>
    @endif
    
    <div style="display: flex; margin-bottom: 10px;">
        <span style="font-weight: 500; color: #333; width: 120px;">Role:</span>
        <span style="color: #666; text-transform: capitalize;">{{ $user->role }}</span>
    </div>
    
    <div style="display: flex; margin-bottom: 10px;">
        <span style="font-weight: 500; color: #333; width: 120px;">Status:</span>
        <span style="color: {{ $user->is_active ? '#28a745' : '#dc3545' }};">
            {{ $user->is_active ? 'Active' : 'Inactive' }}
        </span>
    </div>
</div>

<div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 20px; margin-top: 30px;">
    <div class="card">
        <h3 style="margin-top: 0; color: #333;">Quick Actions</h3>
        <div style="display: flex; flex-direction: column; gap: 10px;">
            <a href="{{ url('/customers/create') }}" class="btn">Add New Customer</a>
            <a href="{{ url('/salesmen/create') }}" class="btn">Add New Salesman</a>
        </div>
    </div>
    
    <div class="card">
        <h3 style="margin-top: 0; color: #333;">Recent Activity</h3>
        <p style="color: #666;">Welcome to your admin panel! Use the sidebar to navigate between different modules.</p>
    </div>
</div>
@endsection
