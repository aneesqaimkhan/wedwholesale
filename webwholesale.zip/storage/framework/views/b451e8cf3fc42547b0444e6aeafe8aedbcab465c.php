<?php $__env->startSection('title', 'Customers'); ?>
<?php $__env->startSection('page-title', 'Customers'); ?>

<?php $__env->startSection('content'); ?>
<div class="page-header">
    <h1 class="page-title">Customers</h1>
    <p class="page-subtitle">Manage your customer database</p>
</div>

<div class="card">
    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
        <h3 style="margin: 0;">Customer List</h3>
        <a href="<?php echo e(route_include_subdirectory('customers.create', ['subdomain' => request()->route('subdomain')])); ?>" class="btn">Add New Customer</a>
    </div>

    <?php if($customers->count() > 0): ?>
        <table class="table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Mobile</th>
                    <th>Address</th>
                    <th>Created At</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($customer->id); ?></td>
                    <td><?php echo e($customer->name); ?></td>
                    <td><?php echo e($customer->mobile); ?></td>
                    <td><?php echo e(Str::limit($customer->address, 50)); ?></td>
                    <td><?php echo e($customer->created_at->format('M d, Y')); ?></td>
                    <td>
                        <a href="<?php echo e(route_include_subdirectory('customers.show', ['subdomain' => request()->route('subdomain'), 'customer' => $customer->id])); ?>" class="btn btn-success" style="padding: 5px 10px; font-size: 12px;">View</a>
                        <a href="<?php echo e(route_include_subdirectory('customers.edit', ['subdomain' => request()->route('subdomain'), 'customer' => $customer->id])); ?>" class="btn btn-warning" style="padding: 5px 10px; font-size: 12px;">Edit</a>
                        <form method="POST" action="<?php echo e(route_include_subdirectory('customers.destroy', ['subdomain' => request()->route('subdomain'), 'customer' => $customer->id])); ?>" style="display: inline;" onsubmit="return confirm('Are you sure you want to delete this customer?')">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-danger" style="padding: 5px 10px; font-size: 12px;">Delete</button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>

        <div style="margin-top: 20px;">
            <?php echo e($customers->links()); ?>

        </div>
    <?php else: ?>
        <div style="text-align: center; padding: 40px; color: #666;">
            <p>No customers found. <a href="<?php echo e(route_include_subdirectory('customers.create', ['subdomain' => request()->route('subdomain')])); ?>">Add your first customer</a></p>
        </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('tenant.layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\webwholesale\resources\views/tenant/customers/index.blade.php ENDPATH**/ ?>