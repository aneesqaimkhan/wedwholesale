

<?php $__env->startSection('title', 'Products'); ?>
<?php $__env->startSection('page-title', 'Products'); ?>

<?php $__env->startSection('content'); ?>
<div class="page-header">
    <h1 class="page-title">Products</h1>
    <p class="page-subtitle">Manage your product database</p>
</div>

<div class="card">
    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
        <h3 style="margin: 0;">Product List</h3>
        <a href="<?php echo e(route_include_subdirectory('products.create', ['subdomain' => request()->route('subdomain')])); ?>" class="btn">Add New Product</a>
    </div>

    <?php if($products->count() > 0): ?>
        <table class="table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Code</th>
                    <th>Product Name</th>
                    <th>Pcs in Box</th>
                    <th>Price (Box)</th>
                    <th>Price (Pcs)</th>
                    <th>Stock (Box/Pcs)</th>
                    <th>Created At</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($product->product_id); ?></td>
                    <td><?php echo e($product->product_code); ?></td>
                    <td><?php echo e($product->product_name); ?></td>
                    <td><?php echo e($product->pcs_in_box); ?></td>
                    <td><?php echo e(number_format($product->n_price_box, 2)); ?></td>
                    <td><?php echo e(number_format($product->n_price_pcs, 2)); ?></td>
                    <td><?php echo e($product->opening_qty_box); ?>/<?php echo e($product->opening_qty_pcs); ?></td>
                    <td><?php echo e($product->created_at->format('M d, Y')); ?></td>
                    <td>
                        <a href="<?php echo e(route_include_subdirectory('products.show', ['subdomain' => request()->route('subdomain'), 'product' => $product->product_id])); ?>" class="btn btn-success" style="padding: 5px 10px; font-size: 12px;">View</a>
                        <a href="<?php echo e(route_include_subdirectory('products.edit', ['subdomain' => request()->route('subdomain'), 'product' => $product->product_id])); ?>" class="btn btn-warning" style="padding: 5px 10px; font-size: 12px;">Edit</a>
                        <form method="POST" action="<?php echo e(route_include_subdirectory('products.destroy', ['subdomain' => request()->route('subdomain'), 'product' => $product->product_id])); ?>" style="display: inline;" onsubmit="return confirm('Are you sure you want to delete this product?')">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-danger" style="padding: 5px 10px; font-size: 12px;">Delete</button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>

        <div style="margin-top: 20px;">
            <?php echo e($products->links()); ?>

        </div>
    <?php else: ?>
        <div style="text-align: center; padding: 40px; color: #666;">
            <p>No products found. <a href="<?php echo e(route_include_subdirectory('products.create', ['subdomain' => request()->route('subdomain')])); ?>">Add your first product</a></p>
        </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('tenant.layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\webwholesale\resources\views/tenant/products/index.blade.php ENDPATH**/ ?>