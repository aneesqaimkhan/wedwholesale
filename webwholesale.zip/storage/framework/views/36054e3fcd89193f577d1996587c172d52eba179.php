<?php $__env->startSection('title', 'Salesmen'); ?>
<?php $__env->startSection('page-title', 'Salesmen'); ?>

<?php $__env->startSection('content'); ?>
<div class="page-header">
    <h1 class="page-title">Salesmen</h1>
    <p class="page-subtitle">Manage your salesman database</p>
</div>

<div class="card">
    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
        <h3 style="margin: 0;">Salesman List</h3>
        <a href="<?php echo e(route_include_subdirectory('salesmen.create', ['subdomain' => request()->route('subdomain')])); ?>" class="btn">Add New Salesman</a>
    </div>

    <?php if($salesmen->count() > 0): ?>
        <table class="table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Mobile</th>
                    <th>Address</th>
                    <th>Created At</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $salesmen; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $salesman): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($salesman->id); ?></td>
                    <td><?php echo e($salesman->name); ?></td>
                    <td><?php echo e($salesman->mobile); ?></td>
                    <td><?php echo e(Str::limit($salesman->address, 50)); ?></td>
                    <td><?php echo e($salesman->created_at->format('M d, Y')); ?></td>
                    <td>
                        <a href="<?php echo e(route_include_subdirectory('salesmen.show', ['subdomain' => request()->route('subdomain'), 'salesman' => $salesman->id])); ?>" class="btn btn-success" style="padding: 5px 10px; font-size: 12px;">View</a>
                        <a href="<?php echo e(route_include_subdirectory('salesmen.edit', ['subdomain' => request()->route('subdomain'), 'salesman' => $salesman->id])); ?>" class="btn btn-warning" style="padding: 5px 10px; font-size: 12px;">Edit</a>
                        <form method="POST" action="<?php echo e(route_include_subdirectory('salesmen.destroy', ['subdomain' => request()->route('subdomain'), 'salesman' => $salesman->id])); ?>" style="display: inline;" onsubmit="return confirm('Are you sure you want to delete this salesman?')">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-danger" style="padding: 5px 10px; font-size: 12px;">Delete</button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>

        <div style="margin-top: 20px;">
            <?php echo e($salesmen->links()); ?>

        </div>
    <?php else: ?>
        <div style="text-align: center; padding: 40px; color: #666;">
            <p>No salesmen found. <a href="<?php echo e(route_include_subdirectory('salesmen.create', ['subdomain' => request()->route('subdomain')])); ?>">Add your first salesman</a></p>
        </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('tenant.layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\webwholesale\resources\views/tenant/salesmen/index.blade.php ENDPATH**/ ?>