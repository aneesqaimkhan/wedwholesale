

<?php $__env->startSection('title', 'Salesman Details'); ?>
<?php $__env->startSection('page-title', 'Salesman Details'); ?>

<?php $__env->startSection('content'); ?>
<div class="page-header">
    <h1 class="page-title">Salesman Details</h1>
    <p class="page-subtitle">View salesman information</p>
</div>

<div class="card">
    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
        <h3 style="margin: 0;">Salesman Information</h3>
        <div style="display: flex; gap: 10px;">
            <a href="<?php echo e(url('/salesmen/' . $salesman->id . '/edit')); ?>" class="btn btn-warning">Edit</a>
            <a href="<?php echo e(url('/salesmen')); ?>" class="btn" style="background: #6c757d;">Back to List</a>
        </div>
    </div>

    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px;">
        <div>
            <div style="margin-bottom: 15px;">
                <strong>Salesman ID:</strong>
                <div style="color: #666;"><?php echo e($salesman->id); ?></div>
            </div>
            
            <div style="margin-bottom: 15px;">
                <strong>Name:</strong>
                <div style="color: #666;"><?php echo e($salesman->name); ?></div>
            </div>
            
            <div style="margin-bottom: 15px;">
                <strong>Mobile:</strong>
                <div style="color: #666;"><?php echo e($salesman->mobile); ?></div>
            </div>
        </div>
        
        <div>
            <div style="margin-bottom: 15px;">
                <strong>Address:</strong>
                <div style="color: #666;"><?php echo e($salesman->address ?: 'Not provided'); ?></div>
            </div>
            
            <div style="margin-bottom: 15px;">
                <strong>Created At:</strong>
                <div style="color: #666;"><?php echo e($salesman->created_at->format('M d, Y H:i')); ?></div>
            </div>
            
            <div style="margin-bottom: 15px;">
                <strong>Last Updated:</strong>
                <div style="color: #666;"><?php echo e($salesman->updated_at->format('M d, Y H:i')); ?></div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('tenant.layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\webwholesale\resources\views/tenant/salesmen/show.blade.php ENDPATH**/ ?>