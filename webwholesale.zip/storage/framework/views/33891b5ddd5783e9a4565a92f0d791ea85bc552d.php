

<?php $__env->startSection('title', 'Sales Invoices'); ?>
<?php $__env->startSection('page-title', 'Sales Invoices'); ?>

<?php $__env->startSection('content'); ?>
    <div class="card">
        <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:15px;">
            <div>
                <h3 class="mb-0">All Invoices</h3>
                <div class="page-subtitle">Recent first</div>
            </div>
            <a href="<?php echo e(route_include_subdirectory('sales_invoices.create')); ?>" class="btn">+ New Invoice</a>
        </div>

        <table class="table">
            <thead>
            <tr>
                <th>#</th>
                <th>Date</th>
                <th>Customer</th>
                <th>Salesman</th>
                <th>Remarks</th>
                <th></th>
            </tr>
            </thead>
            <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $invoices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $inv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($inv->invoice_no); ?></td>
                    <td><?php echo e($inv->invoice_date); ?></td>
                    <td><?php echo e($inv->customer_code); ?> - <?php echo e($inv->customer_name); ?></td>
                    <td><?php echo e($inv->salesman_code); ?> - <?php echo e($inv->salesman_name); ?></td>
                    <td><?php echo e($inv->remarks); ?></td>
                    <td class="text-right">
                        <a href="<?php echo e(route_include_subdirectory('sales_invoices.show', $inv)); ?>" class="btn btn-warning">View</a>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="6" class="text-center">No invoices found.</td></tr>
            <?php endif; ?>
            </tbody>
        </table>

        <div class="mt-3"><?php echo e($invoices->links()); ?></div>
    </div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('tenant.layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\webwholesale\resources\views/tenant/sales_invoices/index.blade.php ENDPATH**/ ?>