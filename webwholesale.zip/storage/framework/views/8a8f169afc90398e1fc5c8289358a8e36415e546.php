

<?php $__env->startSection('title', 'Edit Product'); ?>
<?php $__env->startSection('page-title', 'Edit Product'); ?>

<?php $__env->startSection('content'); ?>
<div class="page-header">
    <h1 class="page-title">Edit Product</h1>
    <p class="page-subtitle">Update product information</p>
</div>

<div class="card">
    <form method="POST" action="<?php echo e(route_include_subdirectory('products.update', ['subdomain' => request()->route('subdomain'), 'product' => $product->product_id])); ?>">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        
        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px;">
            <div class="form-group">
                <label for="product_code">Product Code *</label>
                <input type="text" id="product_code" name="product_code" class="form-control" value="<?php echo e(old('product_code', $product->product_code)); ?>" required>
                <?php $__errorArgs = ['product_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div style="color: #dc3545; font-size: 14px; margin-top: 5px;"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="form-group">
                <label for="product_name">Product Name *</label>
                <input type="text" id="product_name" name="product_name" class="form-control" value="<?php echo e(old('product_name', $product->product_name)); ?>" required>
                <?php $__errorArgs = ['product_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div style="color: #dc3545; font-size: 14px; margin-top: 5px;"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>

        <div style="display: grid; grid-template-columns: 1fr 1fr 1fr 1fr; gap: 20px;">
            <div class="form-group">
                <label for="pcs_in_box">Pcs in Box</label>
                <input type="number" id="pcs_in_box" name="pcs_in_box" class="form-control" value="<?php echo e(old('pcs_in_box', $product->pcs_in_box)); ?>" min="0">
                <?php $__errorArgs = ['pcs_in_box'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div style="color: #dc3545; font-size: 14px; margin-top: 5px;"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="form-group">
                <label for="supplier_id">Supplier ID</label>
                <input type="number" id="supplier_id" name="supplier_id" class="form-control" value="<?php echo e(old('supplier_id', $product->supplier_id)); ?>">
                <?php $__errorArgs = ['supplier_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div style="color: #dc3545; font-size: 14px; margin-top: 5px;"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="form-group">
                <label for="bonus_type">Bonus Type</label>
                <select id="bonus_type" name="bonus_type" class="form-control">
                    <option value="D" <?php echo e(old('bonus_type', $product->bonus_type) == 'D' ? 'selected' : ''); ?>>Deduct (D)</option>
                    <option value="A" <?php echo e(old('bonus_type', $product->bonus_type) == 'A' ? 'selected' : ''); ?>>Add (A)</option>
                </select>
                <?php $__errorArgs = ['bonus_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div style="color: #dc3545; font-size: 14px; margin-top: 5px;"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="form-group">
                <label for="expire_date">Expire Date</label>
                <input type="date" id="expire_date" name="expire_date" class="form-control" value="<?php echo e(old('expire_date', $product->expire_date ? $product->expire_date->format('Y-m-d') : '')); ?>">
                <?php $__errorArgs = ['expire_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div style="color: #dc3545; font-size: 14px; margin-top: 5px;"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>

        <div class="form-group">
            <label for="packing">Packing</label>
            <input type="text" id="packing" name="packing" class="form-control" value="<?php echo e(old('packing', $product->packing)); ?>">
            <?php $__errorArgs = ['packing'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div style="color: #dc3545; font-size: 14px; margin-top: 5px;"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <h3 style="margin: 30px 0 20px 0; color: #333;">Opening Quantities</h3>
        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px;">
            <div class="form-group">
                <label for="opening_qty_box">Opening Qty (Box)</label>
                <input type="number" id="opening_qty_box" name="opening_qty_box" class="form-control" value="<?php echo e(old('opening_qty_box', $product->opening_qty_box)); ?>" min="0">
                <?php $__errorArgs = ['opening_qty_box'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div style="color: #dc3545; font-size: 14px; margin-top: 5px;"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="form-group">
                <label for="opening_qty_pcs">Opening Qty (Pcs)</label>
                <input type="number" id="opening_qty_pcs" name="opening_qty_pcs" class="form-control" value="<?php echo e(old('opening_qty_pcs', $product->opening_qty_pcs)); ?>" min="0">
                <?php $__errorArgs = ['opening_qty_pcs'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div style="color: #dc3545; font-size: 14px; margin-top: 5px;"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>

        <h3 style="margin: 30px 0 20px 0; color: #333;">Minimum Stock</h3>
        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px;">
            <div class="form-group">
                <label for="minimum_stock_box">Minimum Stock (Box)</label>
                <input type="number" id="minimum_stock_box" name="minimum_stock_box" class="form-control" value="<?php echo e(old('minimum_stock_box', $product->minimum_stock_box)); ?>" min="0">
                <?php $__errorArgs = ['minimum_stock_box'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div style="color: #dc3545; font-size: 14px; margin-top: 5px;"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="form-group">
                <label for="minimum_stock_pcs">Minimum Stock (Pcs)</label>
                <input type="number" id="minimum_stock_pcs" name="minimum_stock_pcs" class="form-control" value="<?php echo e(old('minimum_stock_pcs', $product->minimum_stock_pcs)); ?>" min="0">
                <?php $__errorArgs = ['minimum_stock_pcs'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div style="color: #dc3545; font-size: 14px; margin-top: 5px;"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>

        <h3 style="margin: 30px 0 20px 0; color: #333;">Normal Price (N)</h3>
        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px;">
            <div class="form-group">
                <label for="n_price_box">Price per Box</label>
                <input type="number" id="n_price_box" name="n_price_box" class="form-control" value="<?php echo e(old('n_price_box', $product->n_price_box)); ?>" step="0.01" min="0">
                <?php $__errorArgs = ['n_price_box'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div style="color: #dc3545; font-size: 14px; margin-top: 5px;"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="form-group">
                <label for="n_price_pcs">Price per Pcs</label>
                <input type="number" id="n_price_pcs" name="n_price_pcs" class="form-control" value="<?php echo e(old('n_price_pcs', $product->n_price_pcs)); ?>" step="0.01" min="0">
                <?php $__errorArgs = ['n_price_pcs'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div style="color: #dc3545; font-size: 14px; margin-top: 5px;"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>

        <h3 style="margin: 30px 0 20px 0; color: #333;">Trade Price (T)</h3>
        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px;">
            <div class="form-group">
                <label for="t_price_box">Price per Box</label>
                <input type="number" id="t_price_box" name="t_price_box" class="form-control" value="<?php echo e(old('t_price_box', $product->t_price_box)); ?>" step="0.01" min="0">
                <?php $__errorArgs = ['t_price_box'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div style="color: #dc3545; font-size: 14px; margin-top: 5px;"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="form-group">
                <label for="t_price_pcs">Price per Pcs</label>
                <input type="number" id="t_price_pcs" name="t_price_pcs" class="form-control" value="<?php echo e(old('t_price_pcs', $product->t_price_pcs)); ?>" step="0.01" min="0">
                <?php $__errorArgs = ['t_price_pcs'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div style="color: #dc3545; font-size: 14px; margin-top: 5px;"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>

        <h3 style="margin: 30px 0 20px 0; color: #333;">Retail Price (R)</h3>
        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px;">
            <div class="form-group">
                <label for="r_price_box">Price per Box</label>
                <input type="number" id="r_price_box" name="r_price_box" class="form-control" value="<?php echo e(old('r_price_box', $product->r_price_box)); ?>" step="0.01" min="0">
                <?php $__errorArgs = ['r_price_box'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div style="color: #dc3545; font-size: 14px; margin-top: 5px;"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="form-group">
                <label for="r_price_pcs">Price per Pcs</label>
                <input type="number" id="r_price_pcs" name="r_price_pcs" class="form-control" value="<?php echo e(old('r_price_pcs', $product->r_price_pcs)); ?>" step="0.01" min="0">
                <?php $__errorArgs = ['r_price_pcs'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div style="color: #dc3545; font-size: 14px; margin-top: 5px;"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>

        <div style="display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 20px;">
            <div class="form-group">
                <label for="sales_tax">Sales Tax (%)</label>
                <input type="number" id="sales_tax" name="sales_tax" class="form-control" value="<?php echo e(old('sales_tax', $product->sales_tax)); ?>" step="0.01" min="0" max="100">
                <?php $__errorArgs = ['sales_tax'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div style="color: #dc3545; font-size: 14px; margin-top: 5px;"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="form-group">
                <label for="rate_in_percent">Rate in Percent (%)</label>
                <input type="number" id="rate_in_percent" name="rate_in_percent" class="form-control" value="<?php echo e(old('rate_in_percent', $product->rate_in_percent)); ?>" step="0.01" min="0" max="100">
                <?php $__errorArgs = ['rate_in_percent'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div style="color: #dc3545; font-size: 14px; margin-top: 5px;"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="form-group">
                <label for="default_rate_type">Default Rate Type</label>
                <select id="default_rate_type" name="default_rate_type" class="form-control">
                    <option value="N" <?php echo e(old('default_rate_type', $product->default_rate_type) == 'N' ? 'selected' : ''); ?>>Normal (N)</option>
                    <option value="T" <?php echo e(old('default_rate_type', $product->default_rate_type) == 'T' ? 'selected' : ''); ?>>Trade (T)</option>
                    <option value="R" <?php echo e(old('default_rate_type', $product->default_rate_type) == 'R' ? 'selected' : ''); ?>>Retail (R)</option>
                </select>
                <?php $__errorArgs = ['default_rate_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div style="color: #dc3545; font-size: 14px; margin-top: 5px;"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>

        <div class="form-group">
            <label for="company_id">Company ID</label>
            <input type="number" id="company_id" name="company_id" class="form-control" value="<?php echo e(old('company_id', $product->company_id)); ?>">
            <?php $__errorArgs = ['company_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div style="color: #dc3545; font-size: 14px; margin-top: 5px;"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div style="display: flex; gap: 10px; margin-top: 30px;">
            <button type="submit" class="btn">Update Product</button>
            <a href="<?php echo e(route_include_subdirectory('products.index', ['subdomain' => request()->route('subdomain')])); ?>" class="btn" style="background: #6c757d;">Cancel</a>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('tenant.layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\webwholesale\resources\views/tenant/products/edit.blade.php ENDPATH**/ ?>